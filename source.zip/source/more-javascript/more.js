const saySomethingElse = (somethingElse) => {
  console.log(somethingElse); // eslint-disable-line no-console
};

saySomethingElse('Something Else! (more.js)');
